import pickle
import matplotlib.pyplot as plt

# 加载动作数据
with open('all_action_data_episode_0.pkl', 'rb') as f_action:
    all_action_data = pickle.load(f_action)

# 加载观测数据
with open('all_obs_data_episode_0.pkl', 'rb') as f_obs:
    all_obs_data = pickle.load(f_obs)

with open('all_vmax_data0.pkl', 'rb') as f_obs:
    all_vmax_data = pickle.load(f_obs)
# 打印第一个obs数据的结构
print(type(all_obs_data[0]))
print(all_obs_data[0])


robot_4_velocity = [obs[7] for obs in all_obs_data]  # 这里[0]是因为每个obs[7]是一个[10x1]的数组
robot_4_pos = [obs[6] for obs in all_obs_data]  
robot_3_pos = [obs[4] for obs in all_obs_data]  
robot_5_pos = [obs[8] for obs in all_obs_data]  

vmax = [all_vmax_data for vmax in all_vmax_data]  # 这里[0]是因为每个obs[7]是一个[10x1]的数组

# 确保 vmax 和 robot_4_velocity 的长度一致
min_length = min(len(robot_4_velocity), len(all_vmax_data))
robot_4_velocity = robot_4_velocity[:min_length]  # 截断到最小长度
vmax = all_vmax_data[:min_length]  # 截断到最小长度


# 计算机器人之间的位置差的绝对值
diff_4_3 = [abs(robot_4_pos[i] - robot_3_pos[i]) for i in range(len(robot_4_pos))]
diff_4_5 = [abs(robot_4_pos[i] - robot_5_pos[i]) for i in range(len(robot_4_pos))]
# 绘制位置差随时间变化的曲线
plt.figure()
plt.plot(diff_4_3, label='|Robot Position - leader Position|')
plt.plot(diff_4_5, label='|Robot Position - last one Position|')
# 添加一条y=5的虚线，表示最小距离
plt.axhline(y=5, color='b', linestyle='--', label='Minimum Distance between leader and me = 5')
plt.axhline(y=6, color='r', linestyle='--', label='Minimum Distance between last one and me = 6')

# 图表标题和标签
plt.title('Position Difference Between Robots Over Time')
plt.xlabel('Time Step')
plt.ylabel('Position Difference (Absolute Value)')

# 显示图例
plt.legend()

# 显示图像
plt.show()
# 绘制第4个机器人的速度随时间变化曲线和 vmax 曲线
plt.figure()
vmax = [v + 0.02 for v in vmax]
plt.plot(robot_4_velocity, label='Robot me Velocity')
plt.plot(vmax, label='Vmax', linestyle='--')  # 使用虚线绘制 vmax
plt.title('Velocity of Robot me and Vmax Over Time')
plt.xlabel('Time Step')
plt.ylabel('Velocity')
plt.legend()  # 显示图例
plt.show()